package com.project.domain.member;

public enum Gender {
    M, F
}
